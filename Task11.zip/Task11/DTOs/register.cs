﻿using System.ComponentModel.DataAnnotations;

namespace Task11.DTOs
{
    public class register
    {
        public string Name { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [MinLength(8)]
        public string Password { get; set; }
        public string Role { get; set; } = "User";

    }
}
