﻿using Microsoft.AspNetCore.Mvc;

namespace Task12.Controllers
{
    public class TaskItemController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
